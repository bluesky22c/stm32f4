//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by automataKr.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_AUTOMATAKR_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_BTN01                       1001
#define IDC_BTN02                       1002
#define IDC_BTN03                       1003
#define IDC_BTN04                       1004
#define IDC_BTN05                       1005
#define IDC_BTN06                       1006
#define IDC_BTN07                       1007
#define IDC_BTN08                       1008
#define IDC_BTN09                       1009
#define IDC_BTN10                       1010
#define IDC_BTN11                       1011
#define IDC_BTN12                       1012
#define IDC_BTN13                       1013
#define IDC_BTN14                       1014
#define IDC_BTN15                       1015
#define IDC_BUTTON1                     1018
#define IDC_BUTTON2                     1019
#define IDC_BUTTON3                     1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
